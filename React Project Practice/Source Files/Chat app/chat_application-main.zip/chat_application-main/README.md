# Realtime Chat Application

### [Live Site](https://chat-app-jsmastery.netlify.app)

![Chat Application](https://i.ibb.co/vDhx8Md/Whats-App-Image-2021-01-26-at-02-01-43.jpg)

## Introduction
This is a code repository for the corresponding video tutorial. In this video, we will create a full Realtime Chat Application
