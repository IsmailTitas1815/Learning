// @flow

import Comment from "./Comment";

export { Comment as default };
