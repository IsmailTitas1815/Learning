import TabbedCard from "./TabbedCard";

export { TabbedCard as default };
