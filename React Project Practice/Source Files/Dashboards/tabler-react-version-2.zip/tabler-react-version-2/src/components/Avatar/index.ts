import Avatar from "./Avatar";

export { Avatar as default };
