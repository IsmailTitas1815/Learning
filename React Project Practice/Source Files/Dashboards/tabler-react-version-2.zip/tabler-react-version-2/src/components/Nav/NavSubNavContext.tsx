import React from "react";

export const NavSubNavContext = React.createContext<boolean>(false);

export default NavSubNavContext;
