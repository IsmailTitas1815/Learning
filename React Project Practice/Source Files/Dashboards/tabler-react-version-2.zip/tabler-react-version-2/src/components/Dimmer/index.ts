import Dimmer from "./Dimmer";

export { Dimmer as default };
