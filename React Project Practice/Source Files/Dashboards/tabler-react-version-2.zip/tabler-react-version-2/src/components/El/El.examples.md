```jsx
import { El } from "tabler-react";

<El.Div>Hello World</El.Div>;
```
