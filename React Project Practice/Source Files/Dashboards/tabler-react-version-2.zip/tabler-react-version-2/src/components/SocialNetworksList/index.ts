import SocialNetworksList from "./SocialNetworksList";

export { SocialNetworksList as default };
