```jsx
import { Alert } from "tabler-react";

<Alert type="success" hasExtraSpace>
  <a>A normal link</a> <Alert.Link>An Alert.Link</Alert.Link>
</Alert>;
```
