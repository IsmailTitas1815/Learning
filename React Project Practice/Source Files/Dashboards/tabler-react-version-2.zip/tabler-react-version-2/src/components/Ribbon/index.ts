import Ribbon from "./Ribbon";

export { Ribbon as default };
