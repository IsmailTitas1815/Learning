import ProgressCard from "./ProgressCard";

export { ProgressCard as default };
