```jsx
import { Breadcrumb } from "tabler-react";

<Breadcrumb.Item>A Breadcrumb.Item</Breadcrumb.Item>;
```
