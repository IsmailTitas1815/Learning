### Basic Tooltip

```jsx
import { Tooltip, Tag } from "tabler-react";

<Tooltip content="Tooltip" placement="top">
  <Tag>Hover Me!</Tag>
</Tooltip>;
```
