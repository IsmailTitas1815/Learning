import Tooltip from "./Tooltip";

export { Tooltip as default };
