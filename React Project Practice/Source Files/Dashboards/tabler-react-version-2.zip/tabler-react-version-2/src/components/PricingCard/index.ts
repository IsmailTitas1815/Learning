import PricingCard from "./PricingCard";

export { PricingCard as default };
