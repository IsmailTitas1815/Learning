import Progress from "./Progress";

export { Progress as default };
