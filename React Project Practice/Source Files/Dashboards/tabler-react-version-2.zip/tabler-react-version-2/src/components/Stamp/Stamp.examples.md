```jsx
import { Stamp } from "tabler-react";

<Stamp size="sm" className="mr-1">
  A
</Stamp>
<Stamp className="mr-1">B</Stamp>
<Stamp color="primary" className="mr-1">
  C
</Stamp>
<Stamp color="orange" icon="globe" />
```
