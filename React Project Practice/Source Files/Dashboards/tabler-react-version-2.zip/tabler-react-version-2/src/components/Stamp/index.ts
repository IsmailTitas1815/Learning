import Stamp from "./Stamp";

export { Stamp as default };
