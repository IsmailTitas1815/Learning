import Icon from "./Icon";

export { Icon as default };
