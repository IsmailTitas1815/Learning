```jsx
import { Tag } from "tabler-react";

<Tag.List>
  <Tag>First tag</Tag>
  <Tag>Second tag</Tag>
  <Tag>Third tag</Tag>
</Tag.List>;
```
