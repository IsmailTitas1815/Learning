import Tag from "../Badge/Badge";

export { Tag as default, Tag };
