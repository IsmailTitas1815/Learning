import TagAddOn from "../Badge/BadgeAddOn";

export { TagAddOn as default, TagAddOn };
