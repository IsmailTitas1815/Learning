import TagList from "../Badge/BadgeList";

export { TagList as default, TagList };
