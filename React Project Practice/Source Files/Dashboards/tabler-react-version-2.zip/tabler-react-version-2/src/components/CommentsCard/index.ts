import CommentsCard from "./CommentsCard";

export { CommentsCard as default };
