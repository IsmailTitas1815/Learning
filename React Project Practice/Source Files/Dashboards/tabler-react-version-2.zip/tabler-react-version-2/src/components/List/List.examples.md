```jsx
import { List } from "tabler-react";

<List>
  <List.Item>An Item</List.Item>
  <List.Item>Another Item</List.Item>
  <List.Item>A third item</List.Item>
</List>;
```

#### Unstyled

```jsx
import { List } from "tabler-react";

<List unstyled>
  <List.Item>An Item</List.Item>
  <List.Item>Another Item</List.Item>
  <List.Item>A third item</List.Item>
</List>;
```
