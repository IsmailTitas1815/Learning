import List from "./List";

export { List as default };
