```jsx
import { List } from "tabler-react";

<List.Group>
  <List.GroupItem>An Item</List.GroupItem>
  <List.GroupItem>Another Item</List.GroupItem>
  <List.GroupItem>A third item</List.GroupItem>
</List.Group>;
```
