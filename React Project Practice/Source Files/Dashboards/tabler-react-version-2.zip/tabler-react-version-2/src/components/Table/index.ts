import Table from "./Table";

export { Table as default };
