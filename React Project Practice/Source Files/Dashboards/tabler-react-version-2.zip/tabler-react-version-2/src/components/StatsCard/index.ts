import StatsCard from "./StatsCard";

export { StatsCard as default };
