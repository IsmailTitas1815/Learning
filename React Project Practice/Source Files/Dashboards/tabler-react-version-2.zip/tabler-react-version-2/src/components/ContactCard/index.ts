import ContactCard from "./ContactCard";

export { ContactCard as default };
