```jsx
import { Header } from "tabler-react";

<Header size={1}>A div sized like a h1</Header>;
```
