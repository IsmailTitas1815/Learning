```jsx
import { Badge } from "tabler-react";

<Badge.List>
  <Badge>First Badge</Badge>
  <Badge>Second Badge</Badge>
  <Badge>Third Badge</Badge>
</Badge.List>;
```
