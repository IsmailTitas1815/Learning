import Profile from "./Profile";

export { Profile as default };
