### Image input

```jsx
import { Form } from "tabler-react";

<Form.Group label="Image input">
  <Form.ImageCheck>
    <Form.ImageCheckItem
      imageURL="/demo/photos/nathan-anderson-316188-500.jpg"
      value="1"
      col={{ sm: 2 }}
    />
    <Form.ImageCheckItem
      imageURL="/demo/photos/nathan-dumlao-287713-500.jpg"
      value="2"
      col={{ sm: 2 }}
    />
    <Form.ImageCheckItem
      imageURL="/demo/photos/nicolas-picard-208276-500.jpg"
      value="3"
      col={{ sm: 2 }}
    />
    <Form.ImageCheckItem
      imageURL="/demo/photos/oskar-vertetics-53043-500.jpg"
      value="4"
      col={{ sm: 2 }}
    />
    <Form.ImageCheckItem
      imageURL="/demo/photos/priscilla-du-preez-181896-500.jpg"
      value="5"
      col={{ sm: 2 }}
    />
    <Form.ImageCheckItem
      imageURL="/demo/photos/ricardo-gomez-angel-262359-500.jpg"
      value="6"
      col={{ sm: 2 }}
    />
  </Form.ImageCheck>
</Form.Group>;
```
