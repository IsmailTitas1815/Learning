```jsx
import { Button, Form } from "tabler-react";

<Form.InputGroup>
  <Form.InputGroupPrepend>
    <Button as="a" color="primary" href="http://www.google.com">
      Go!
    </Button>
  </Form.InputGroupPrepend>
  <Form.Input placeholder="Search for..." />
</Form.InputGroup>;
```
