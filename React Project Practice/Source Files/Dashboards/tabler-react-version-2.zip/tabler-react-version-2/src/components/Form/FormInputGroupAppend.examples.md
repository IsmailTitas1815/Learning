```jsx
import { Button, Form } from "tabler-react";

<Form.InputGroup>
  <Form.Input placeholder="Search for..." />
  <Form.InputGroupAppend>
    <Button as="a" color="primary" href="http://www.google.com">
      Go!
    </Button>
  </Form.InputGroupAppend>
</Form.InputGroup>;
```
