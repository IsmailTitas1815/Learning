```jsx
import { Steps } from "tabler-react";

<Steps>
  <Steps.Step href="#">Step 1</Steps.Step>
  <Steps.Step href="#">Step 2</Steps.Step>
  <Steps.Step href="#" active>
    Step 3
  </Steps.Step>
  <Steps.Step href="#" disabled>
    Step 4
  </Steps.Step>
</Steps>;
```
