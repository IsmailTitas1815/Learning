import Divider from "./Divider";

export { Divider as default, Divider };
