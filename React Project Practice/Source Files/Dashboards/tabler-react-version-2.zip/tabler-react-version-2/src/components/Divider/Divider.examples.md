```jsx
import { Breadcrumb } from "tabler-react";

<Divider>OR</Divider>;
```
