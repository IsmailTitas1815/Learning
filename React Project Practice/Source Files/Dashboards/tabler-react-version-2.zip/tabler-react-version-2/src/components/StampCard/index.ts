import StampCard from "./StampCard";

export { StampCard as default };
