```jsx
import { StampCard } from "tabler-react";

<StampCard header="Headline" footer="Something Else" color="yellow" />
<StampCard icon="check" color="green">
  Success!
</StampCard>
```
