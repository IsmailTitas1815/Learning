```jsx
import { Avatar, Button, Timeline } from "tabler-react";

<Timeline show>
  <Timeline.Header
    avatar="./img/avatars/002m.jpg"
    title="Mallory Hulme"
    timestamp="11 mins ago"
  />
  <Timeline.Body>Hello, world! This is a toast message.</Timeline.Body>
</Timeline>;
```
