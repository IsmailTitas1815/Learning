// @flow

import BlogCard from "./BlogCard";

export { BlogCard as default };
