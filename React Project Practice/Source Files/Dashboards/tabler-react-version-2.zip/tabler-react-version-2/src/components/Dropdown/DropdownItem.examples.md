```jsx
<Dropdown>
  <Dropdown.Trigger>Menu</Dropdown.Trigger>
  <Dropdown.Menu>
    <Dropdown.Item icon="user">Profile</Dropdown.Item>
    <Dropdown.Item badge="New !" badgeType="success">
      Notifications
    </Dropdown.Item>
    <Dropdown.ItemDivider />
    <Dropdown.Item value="Logout" />
  </Dropdown.Menu>
</Dropdown>
```
