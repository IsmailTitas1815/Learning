import StoreCard from "./StoreCard";

export { StoreCard as default };
