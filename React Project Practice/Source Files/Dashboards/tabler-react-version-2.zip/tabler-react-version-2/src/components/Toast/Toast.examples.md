```jsx
import { Avatar, Button, Toast } from "tabler-react";

<Toast show>
  <Toast.Header
    avatar="./img/avatars/002m.jpg"
    title="Mallory Hulme"
    timestamp="11 mins ago"
  />
  <Toast.Body>Hello, world! This is a toast message.</Toast.Body>
</Toast>;
```
