```jsx
import { Grid } from "tabler-react";

<Grid.Row>
  <Grid.Col>A</Grid.Col>
  <Grid.Col>B</Grid.Col>
  <Grid.Col>C</Grid.Col>
</Grid.Row>;
```
