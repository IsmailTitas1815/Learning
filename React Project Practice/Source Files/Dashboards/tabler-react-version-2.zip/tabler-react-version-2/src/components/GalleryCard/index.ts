import GalleryCard from "./GalleryCard";

export { GalleryCard as default };
