```jsx
import { RegisterPage } from "tabler-react";

<RegisterPage />;
```
