```jsx
import { ForgotPasswordPage } from "tabler-react";

<ForgotPasswordPage />;
```
