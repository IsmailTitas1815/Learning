```jsx
import { LoginPage } from "tabler-react";

<LoginPage />;
```
