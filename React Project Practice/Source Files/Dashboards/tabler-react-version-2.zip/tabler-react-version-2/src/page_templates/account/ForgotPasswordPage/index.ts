import ForgotPasswordPage from "./ForgotPasswordPage";

export default ForgotPasswordPage;
