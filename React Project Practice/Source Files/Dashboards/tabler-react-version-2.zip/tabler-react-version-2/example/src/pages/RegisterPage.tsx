import * as React from "react";

import { RegisterPage as TablerRegisterPage } from "tabler-react";

type Props = {};

function RegisterPage(props: Props) {
  return <TablerRegisterPage />;
}

export default RegisterPage;
