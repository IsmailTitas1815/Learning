import React from "react";

import SiteWrapper from "../SiteWrapper";

function Empty() {
  return <SiteWrapper>Empty</SiteWrapper>;
}

export default Empty;
