declare module "react-c3js";
declare module "d3-scale";
declare module "react-simple-maps";
