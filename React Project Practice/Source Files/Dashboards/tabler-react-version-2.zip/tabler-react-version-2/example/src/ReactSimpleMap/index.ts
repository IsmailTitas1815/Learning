import ReactSimpleMap from "./ReactSimpleMap";

export { ReactSimpleMap as default };
