from django.apps import AppConfig


class SimplefirstappConfig(AppConfig):
    name = 'simpleFirstApp'
