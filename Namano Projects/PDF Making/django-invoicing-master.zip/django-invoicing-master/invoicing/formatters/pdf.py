from . import InvoiceFormatter


class PDFFormatter(InvoiceFormatter):
    pass