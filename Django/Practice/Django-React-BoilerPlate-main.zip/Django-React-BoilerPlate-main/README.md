# to start

```
git clone
python -m venv venv
pip install ir requirements.txt
```

```javascript
npm i
npm run build
```

```python
python manage.py runserver
```
