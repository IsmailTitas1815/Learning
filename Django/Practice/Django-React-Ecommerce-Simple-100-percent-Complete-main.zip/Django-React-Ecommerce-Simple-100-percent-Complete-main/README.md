# to start

```
git clone
python -m venv venv
pip install -r requirements.txt
```
```python
python manage.py runserver
```
# Full Website in Gif
<img src="screenshots/full.gif" />

# Home Page
<img src="screenshots/home.png" />
